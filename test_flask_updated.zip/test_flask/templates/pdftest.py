import pdfkit

pdfkit.from_file('/templates/invoice.html','invoice.pdf') 
