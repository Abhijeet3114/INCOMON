from flask import Flask,render_template, request
from flask_mysqldb import MySQL
from wtforms import Form, StringField, TextAreaField, PasswordField, validators
from passlib.hash import sha256_crypt
from functools import wraps

app = Flask(__name__)

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
#app.config['MYSQL_PASSWORD'] = '123456'
app.config['MYSQL_DB'] = 'myflaskapp'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'
# init MYSQL
mysql = MySQL(app)

@app.route('/')
def index():
	return render_template('index.html')

class RegisterForm(Form):
    panid = StringField('PanNumber', [validators.Length(min=1, max=10)])
    name = StringField('name', [validators.Length(min=4, max=25)])
    adhaar = StringField('adhaar',[validators.Length(min=1, max= 12)])
    email = StringField('email', [validators.Length(min=6, max=50)])
    password = PasswordField('password', [
        validators.DataRequired(),
        validators.EqualTo('confirm', message='Passwords do not match')
    ])
    confirm = PasswordField('Confirm Password')


# User Register
@app.route('/index', methods=['GET', 'POST'])
def register():
    form = RegisterForm(request.form)
    if request.method == 'POST' and form.validate():
        panid = form.panid.data
        email = form.email.data
        name = form.name.data
        adhaar = form.adhaar.data
        password = sha256_crypt.encrypt(str(form.password.data))

        # Create cursor
        cur = mysql.connection.cursor()

        # Execute query
        cur.execute("INSERT INTO user(panid,  password) VALUES(%s, %s)", (panid, password))
        cur.execute("INSERT INTO user_info(adhaar,panid,name,email) VALUES(%s, %s. %s, %s)", (adhaar, panid, name, email))
        # Commit to DB
        mysql.connection.commit()

        # Close connection
        cur.close()

        flash('You are now registered and can log in', 'success')

        return redirect(url_for('/main.html'))
    return render_template('index.html', form=form)

def tax_calculator(taxable_income):
    temp_income = taxable_income
    liable = 0;
    slab_range = 250000;
    n = int(temp_income / slab_range)
    if(n <= 0):
        return 0
    percentage = 0;
    for i in range(n):
        liable += slab_range * (percentage / 100)
        temp_income = temp_income - slab_range;
        percentage = percentage + 5;
        if(temp_income < slab_range):
            break;
    liable += temp_income * (percentage / 100)
    liable = liable + (liable * 0.04)
    return liable 

def gross_income_calculator(gross_income_sal, interest, other_sources):
    return gross_income_sal + interest + other_sources

def  total_deduction_calculator(ppf,epf,elss,lip,mip1,mip2,fees,nps,don,interest,fda):
    self_health = mip1;
    parents = mip2;
    d_80c = ppf+epf+elss
    d_80tta = interest
    d_80u = fees
    if(mip1 > 25000):
        self_health = 25000
    if(mip2 > 50000):
        parents = 50000
    if(d_80c > 150000):
        d_80c = 150000
    if(d_80tta > 10000):
        d_80tta = 10000
    if(fees > 150000):
        d_80u = 150000
    return d_80tta + d_80c + parents + self_health + d_80u + don + nps + fda

def gross_income_from_sal(a_basic_salary, LTA, expense, spa, std_deduction,taxable_hra):
    taxable_lta = (LTA - expense)
    if(taxable_lta < 0):
        taxable_lta = 0             #if bill amount is exceding LTA then taxable LTA should be 0
    return a_basic_salary + taxable_hra + spa + taxable_lta - std_deduction;


def taxable_hra_calc(city,a_basic_salary, hra, rent_paid):
    result = hra;   
    if(city == "Metro" or city == "metro"):     
        half_ab = a_basic_salary * 0.5
    else:
        half_ab = a_basic_salary * 0.4
    ten_ab = a_basic_salary * 0.1
    excess_rent = rent_paid - ten_ab
    if(excess_rent < half_ab):
        result = hra - excess_rent
    else:
        result = hra - half_ab
    if(result > 0):
        return result
    else:   
        return 0 

#ButtonPressed = 0
@app.route('/main.html',methods=['GET','POST'])
def dashboard():
    if request.method == 'POST':
        city = request.form['city']
        sex = request.form['sex']
        age = request.form['age']
        #INCOME FROM SALARY
        a_basic_salary = float(request.form['salary'])
        hra = float(request.form['hra'])
        rent_paid = float(request.form['rent'])
        spa = float(request.form['spa'])
        LTA = float(rquest.form['lta'])
        expense = float(request.form['exp'])
        taxable_hra=taxable_hra_calc(city,a_basic_salary,hra,rent_paid)
        gross_income_sal = gross_income_from_sal(a_basic_salary, LTA, expense, spa, std_deduction,taxable_hra)
        #INCOME FROM OTHER SOURCES
        interest = float(request.form['interest']) #interest from savings account
        fda = float(request.form['fda']) #interest on FD Account 
        agr = float(request.form['agr'])
        gifts = float(request.form['gifts'])
        other_sources = fda + agr + gifts
        gross_income = gross_income_calculator(gross_income_sal,interest,other_sources)


        #DEDUCTIONS
        ppf = float(request.form['ppf']) 
        epf = float(request.form['epf']) 
        elss = float(request.form['elss'])
        lip = float(request.form['lip']) #life insurance premium
        mip1 = float(request.form['mip1']) #medical insurance premium for self and family
        mip2 = float(request.form['mip2']) #medical insurance premium for parents
        fees = float(request.form['fees'])
        nps = float(request.form['nps'])
        don = float(request.form['don'])
        total_deductions = total_deduction_calculator(ppf,epf,elss,lip,mip1,mip2,fees,nps,don,interest,fda)

        taxable_income = gross_income - total_deductions

        tax_liable = tax_calculator(taxable_income)

        #atd = float(request.form['atd'])
        #tds = float(request.form['tds'])
        #tcs = float(request.form['tcs'])
        #sat = float(request.form['sat'])

        #tax_already_paid = atd + tds + tcs + sat

        #income_tax_payable = tax_liable - tax_already_paid


        return render_template('main.html')

        # I think you want to increment, that case ButtonPressed will be plus 1
    return render_template('main.html')
# User login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Get Form Fields
        username = request.form['username']
        password_candidate = request.form['password']

        # Create cursor
        cur = mysql.connection.cursor()

        # Get user by username
        result = cur.execute("SELECT * FROM user WHERE panid = %s", [panid])

        if result > 0:
            # Get stored hash
            data = cur.fetchone()
            password = data['password']

            # Compare Passwords
            if sha256_crypt.verify(password_candidate, password):
                # Passed
                session['logged_in'] = True
                session['panid'] = panid

                flash('You are now logged in', 'success')
                return redirect(url_for('main'))
            else:
                error = 'Invalid login'
                return render_template('index.html', error=error)
            # Close connection
            cur.close()
        else:
            error = 'PAN ID not registered'
            return render_template('index.html', error=error)

    return render_template('index.html')

if __name__ == '__main__':
	app.run(debug=True)