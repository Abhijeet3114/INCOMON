import pdfkit

pdfkit.from_file('invoice.html','invoice.pdf') 
